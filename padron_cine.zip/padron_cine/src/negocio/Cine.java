package negocio;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;

public class Cine{
	private ArrayList<Pelicula> listaPeliculas = new ArrayList<>();

	public Cine(){
		cargarPeliculas();
	}

	private void cargarPeliculas(){
		Scanner sc = null;
		try{
			File fichero = new File("cine.csv");
			//Crea el fichero si no existe
			fichero.createNewFile();
			sc = new Scanner(fichero);
			sc.useDelimiter(",|\n");
			while(sc.hasNext()){
				listaPeliculas.add(new Pelicula(sc.next(), sc.next(), sc.next()));
			}
		}catch(IOException ex){
			System.out.println("Error en la lectura del fichero de peliculas.");
			System.out.println("A continuación se muestra más información:");
			System.out.println(ex);
		}finally{
			if (sc != null) sc.close();
		}

	}

	public void annadir(Pelicula pelicula){
		listaPeliculas.add(pelicula);
		volcarPeliculas();
	}

	private void volcarPeliculas(){
		FileWriter fw = null;
		try{
			fw = new FileWriter("cine.csv");
			for(Pelicula pelicula : listaPeliculas){
				fw.write(pelicula.getGenero() + "," + pelicula.getDirector() + "," + pelicula.getProductora()+"\n");
			}
		}catch(IOException ex){
			System.out.println("No se ha podido añadir el nuevo Pelicula. Error en la escritura del fichero");
			System.out.println("A continuación se muestra más información:");
			System.out.println(ex);
		}finally{
			try{
				if (fw != null) fw.close();
			}catch(IOException ex){
				System.out.println(ex);
			}
		}
	}

	@Override
        public String toString(){
		StringBuilder strPeliculas = new StringBuilder();
		for(Pelicula pelicula : listaPeliculas) strPeliculas.append(pelicula + "\n"); 
		return strPeliculas.toString();
	}	
}
