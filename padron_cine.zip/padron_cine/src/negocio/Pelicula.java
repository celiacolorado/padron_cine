package negocio;

public class Pelicula{
	private String genero, director, productora;

	public Pelicula(String genero, String director, String productora){
		this.genero = genero;
		this.director = director;
		this.productora = productora;
	}

	@Override
	public String toString(){
		return getGenero() + "," + getDirector() + "," + getProductora(); 
	}

	public String getGenero(){
		return genero;
	}

	public String getDirector(){
		return director;
	}

	public String getProductora(){
		return productora;
	}
}
